<?php

$db_host = 'localhost';
$db_name = 'u_230154715_db';
$username = 'u-230154715';
$password = 'Q7B7tIaWzZozndi';

try {
	$db = new PDO("mysql:dbname=$db_name;host=$db_host", $username, $password);
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $ex) {
	echo("Failed to connect to the database.<br>");
	echo($ex->getMessage());
	exit;
}

try {
    // Prepare a select statement
    $sql = "SELECT * FROM projects"; 
    $stmt = $db->prepare($sql);
    
    // Execute the statement
    $stmt->execute();
    
    // Fetch all rows as an associative array
    $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $ex) {
    echo "An Error occured!"; //user friendly message
    error_log($ex->getMessage()); //writes the error to the log
}


?>

<html lang="en">
<head>
	<title>records</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/year.jpg');">
		

        <?php foreach($projects as $project): ?>
    <div class="project-container">
        <div class="project-details">
            <strong>Project ID:</strong> <?= htmlspecialchars($project['pid']) ?><br>
            <strong>Title:</strong> <?= htmlspecialchars($project['title']) ?><br>
            <strong>Start Date:</strong> <?= htmlspecialchars($project['start_date']) ?><br>
            <strong>End Date:</strong> <?= htmlspecialchars($project['end_date']) ?><br>
            <strong>Phase:</strong> <?= htmlspecialchars($project['phase']) ?><br>
            <strong>Description:</strong> <?= htmlspecialchars($project['description']) ?><br>
        </div>
    </div>
<?php endforeach; ?>        </div>
    @endforeach
</div> 
<div class="container-login100-form-btn">
                        <a href="login.php" class="login100-form-btn" style="text-decoration: none; color: rgb(54, 54, 54); margin-top: 10px;">
                            login
                        </a>
                    </div>
					</div>
				</form>
			</div>
		</div>
	</div>
	
	<div id="dropDownSelect1"></div>
	
	<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
</body>
</html>
