<?php
$db_host = 'localhost';
$db_name = 'u_230154715_db';
$username = 'u-230154715';
$password = 'Q7B7tIaWzZozndi';

// Create connection
$conn = new mysqli($db_host, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (empty($_POST['title'])) {
    die('The title field is required.');
}


$title = trim($_POST['title']); 
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$phase = $_POST['phase'];
$description = $_POST['description'];


if ($title === '') {
    die('Spaces are NOT an acceptable title.');
}


if ($title === '' || $start_date === '' || $end_date === '' || $phase === '' || $description === '') {
    die('All fields are required.');
}


$current_date = new DateTime();
$current_date->setTime(0, 0, 0); 

$start_date_obj = new DateTime($start_date);
$end_date_obj = new DateTime($end_date);

if ($start_date_obj < $current_date) {
    die("The start or end date can NOT be in the past.");
}

if ($end_date_obj < $current_date) {
    die("The start or end date can NOT be in the past.");
}

if ($start_date_obj == $current_date || $end_date_obj == $current_date) {
    die("The start or end date can NOT be set on the present day.");
}

// Check if start and end dates are the same
if ($start_date_obj == $end_date_obj) {
    die("The start and end date can NOT be on the same day.");
}


session_start();
if (!isset($_SESSION['uid'])) {
    die('User not logged in.'); 
}
$uid = $_SESSION['uid'];

// Prepare and bind for the `projects` table
$stmt = $conn->prepare("INSERT INTO projects (title, start_date, end_date, phase, description, uid) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssi",  $title, $start_date, $end_date, $phase, $description, $uid);

// Execute the statement
$stmt->execute();

echo "New record created successfully";

// Close statement and connection
$stmt->close();
$conn->close();
?>
