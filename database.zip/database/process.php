<?php
// Check if the form has been submitted with the 'submitted' key
if (isset($_POST['submitted'])) {
    // connect to the database
    require_once('db.php');
    
    // Use ternary operators to fetch POST data and provide defaults
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    
    // Validate the input
    if (empty($username)) {
        echo "Username is required.";
        exit;
    }
    if (empty($password)) {
        echo "Password is required.";
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format";
        exit;
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Prepare and execute the SQL statement
    try {
        $stmt = $db->prepare("INSERT INTO users (username, password, email) VALUES (?, ?, ?)");
        $stmt->execute([$username, $hashedPassword, $email]);

        if ($stmt->rowCount() > 0) {
            echo "User registered successfully! <a href='login.php'>Click here to login</a>";
        } else {
            echo "User registration failed.";
        }
    } catch (Exception $e) {
        // Handle any errors
        echo 'Registration failed: ' . $e->getMessage();
    }
} else {
    // The form was not submitted correctly.
    echo "Error: Form not submitted.";
}
?>
