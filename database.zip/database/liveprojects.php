<?php

$db_host = 'localhost';
$db_name = 'jubrilbase';
$username = 'root';
$password = '';

try {
    $db = new PDO("mysql:dbname=$db_name;host=$db_host", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $ex) {
    echo("Failed to connect to the database.<br>");
    echo($ex->getMessage());
    exit;
}

try {
    
    $sql = "SELECT * FROM projects"; 
    $stmt = $db->prepare($sql);
    
    
    $stmt->execute();
    
    
    $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $ex) {
    echo "An Error occured!"; 
    error_log($ex->getMessage()); 
}

?>

<html lang="en">
<head>
    <title>Project Records</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <style>
        body, html {
            height: 100%;
            margin: 0;
        }

        .container-login100 {
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover; 
            height: 100%;
        }

        .project-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            width: 100%;
            height: 100%;
        }

        .project-details {
            background: rgba(255, 255, 255, 0.8);
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            flex-basis: calc(33% - 20px);
            box-sizing: border-box;
            overflow: hidden;
        }

        @media (max-width: 768px) {
            .project-details {
                flex-basis: calc(50% - 20px);
            }
        }

        @media (max-width: 480px) {
            .project-details {
                flex-basis: 100%;
            }
        }
    </style>
</head>
<body>
    
    <div class="container-login100" style="background-image: url('images/year.jpg');"> <!-- Inline style for background image -->
        <div class="project-container">
            <?php foreach($projects as $project): ?>
                <div class="project-details">
                    <strong>Project ID:</strong> <?= htmlspecialchars($project['pid']) ?><br>
                    <strong>Title:</strong> <?= htmlspecialchars($project['title']) ?><br>
                    <strong>Start Date:</strong> <?= htmlspecialchars($project['start_date']) ?><br>
                    <strong>End Date:</strong> <?= htmlspecialchars($project['end_date']) ?><br>
                    <strong>Phase:</strong> <?= htmlspecialchars($project['phase']) ?><br>
                    <strong>Description:</strong> <?= htmlspecialchars($project['description']) ?><br>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
  
</body>
</html>
