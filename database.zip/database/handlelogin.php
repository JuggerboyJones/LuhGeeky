<?php

session_start();

$db_host = 'localhost';
$db_name = 'jubrilbase';
$username = 'root';
$password = '';

try {
    $db = new PDO("mysql:dbname=$db_name;host=$db_host", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = isset($_POST['username']) ? trim($_POST['username']) : null;
        $password = isset($_POST['password']) ? $_POST['password'] : null;

        if ($username === null || $password === null) {
            echo "Username and Password are required.";
            exit;
        }

        $stmt = $db->prepare("SELECT * FROM users WHERE LOWER(username) = LOWER(:username)");
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (password_verify($password, $user['password'])) {
                session_regenerate_id();
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['uid'] = $user['uid']; 
                $uid = $_SESSION['uid']; // Assigning $uid from session to a variable
                header("Location: project.php"); // Redirect only when login matches
                exit;
            } else {
                echo "Invalid password.";
            }
        } else {
            echo "User not found.";
        }
    }
} catch(PDOException $ex) {
    echo("Failed to connect to the database.<br>");
    echo($ex->getMessage());
    exit;
}

?>
